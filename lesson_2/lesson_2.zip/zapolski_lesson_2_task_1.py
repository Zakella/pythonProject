var = 15*3
print(type(var))

var = 15 / 3
print(type(var))

var = 15 // 2
print(type(var))

var = 15 ** 2
print(type(var))
